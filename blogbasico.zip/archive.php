<?php
/**
 * The template for displaying archive pages
 *
 * @package blogbasico
 */

// header
get_header();

// blog posts
get_template_part('template-parts/blog-posts');

// footer
get_footer();
