<?php
/**
 * The template for displaying search results pages
 *
 * @package blogbasico
 */

// header
get_header();

// blog posts
get_template_part('template-parts/blog-posts');

// footer
get_footer();
